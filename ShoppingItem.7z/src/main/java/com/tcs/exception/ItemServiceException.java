package com.tcs.exception;

public class ItemServiceException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemServiceException() {
		// TODO Auto-generated constructor stub
	}

}
