package com.tcs.exception;

public class CustomerServiceException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerServiceException() {
		// TODO Auto-generated constructor stub
	}

}
